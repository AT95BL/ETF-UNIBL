#!/bin/bash

lozinke="lozinka*"

for lozinka in $lozinke
do
	r1=`openssl passwd -apr1 -salt lozinka1 -in $lozinka`
	r2=`openssl passwd -apr1 -salt lozinka7 -in $lozinka`
	r3=`openssl passwd -apr1 -salt wAgnh5WA -in $lozinka`

	if [[ "$r1" == "$(<otisak1.dec)" ]] then 
		echo -e "r1: $lozinka"
	fi

	if [[ "$r2" == "$(<otisak2.dec)" ]] then
		echo -e "r2: $lozinka"
	fi

	if [[ "$r3" == "$(<otisak3.dec)" ]] then
	       echo -e "r3: $lozinka"
	fi	       
done

#lozinka18.txt
#lozinka3.txt
#lozinka30.txt

algs=`openssl enc -list | grep "aes-256"`

for alg in $algs
do
	openssl enc $alg -d -in sifrat.dec -kfile lozinka30.txt -out sifrat2.dec 2>error.txt
	openssl enc $alg -d -in sifrat2.dec -kfile lozinka3.txt -out sifrat3.dec 2>error.txt
	openssl enc $alg -d -in sifrat3.dec -kfile lozinka18.txt -out sadrzaj.txt 2>error.txt
	cat sadrzaj.txt
done

#DANAS JE ISPIT IZ KRIPTOGRAFIJE
