#!/bin/bash

certs="client*"

for cert in $certs
do
	r=`openssl verify -CAfile cacert.pem -verbose $cert 2>error.txt`
	if [[ "$r" =~ "OK" ]] then
		echo $cert
	fi
done

#clientcert15.crt
#clientcert27.crt
#clientcert29.crt
