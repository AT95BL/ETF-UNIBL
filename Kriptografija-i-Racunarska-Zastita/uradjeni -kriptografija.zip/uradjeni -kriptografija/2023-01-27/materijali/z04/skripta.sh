#!/bin/bash

otisci=$(<otisci.dec)
ulazi="ulaz*"

for otisak in $otisci
do
	alg=`echo $otisak | cut -d '$' -f 2`
	salt=`echo $otisak | cut -d '$' -f 3`
	hash=`echo $otisak | cut -d '$' -f 4`
	for ulaz in $ulazi
	do
		r=`openssl passwd -$alg -salt $salt -in $ulaz 2>error.txt`
		if [[ "$r" =~ "$hash" ]] then
			echo "$ulaz"
		fi
	done
done

#ulaz14.txt
#ulaz22.txt
#ulaz40.txt
#ulaz41.txt
