#!/bin/bash

kljucevi="kljuc*"
privKey=$(<priv.key)	#	privkey=$(cat priv.key)
for kljuc in $kljucevi
do
	openssl rsa -in $kljuc -inform DER -out pem$kljuc -outform PEM

	if [[ "$privKey" =~ "$(<pem$kljuc)" ]] then	# ==~ proverava da li se prvi string nalazi u drugom
		echo $otisak
		echo "$kljuc"
	fi
done

#kljuc91.key
