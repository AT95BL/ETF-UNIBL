#!/bin/bash

keystores="keystore*"

for keystore in $keystores
do
	r=`keytool -list -v -keystore $keystore -storepass sigurnost 2>error.txt`

	if [[ "$r" =~ "serverAuth" ]] then
		echo $keystore
	fi
done

#keystore22.jks
