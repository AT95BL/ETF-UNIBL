#/bin/bash

envs="env*"
keys="kljuc*"

for env in $envs
do
	for key in $keys
	do
		r=`openssl rsautl -decrypt -in $env -inkey $key 2>error.txt`
		if [[ "$r" != "" ]] then
			openssl enc -camellia-128-cfb -d -in sifrat.dec -key 
		fi
	done
done

#Bravo, nasli ste rjesenje :).
