#!/bin/bash

poruke="poruka*"

for poruka in $poruke
do
	openssl enc -base64 -d -in $poruka -out base$poruka
done
