#!/bin/bash

keys="sess_keys/sess*"
poruke="poruke/base*"

#for key in $keys
#do
	#r=`openssl rsautl -decrypt -in $key -inkey client.key`
	#echo $r
#done

for poruka in $poruke
do
	r=`openssl enc -d -aes-192-ofb -in $poruka -k sigurnost33 2>error.txt`
	#echo $poruk
	echo -e "$r"
done


#aes-192-ofb
#sigurnost33
