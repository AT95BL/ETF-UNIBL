#!/bin/bash

certs="cert*"

for cert in $certs
do
	r=`openssl verify -CAfile CA/ca.pem -verbose $cert 2>error.txt`
	if [[ $r =~ "OK" ]] then
		echo $cert
	fi
done
